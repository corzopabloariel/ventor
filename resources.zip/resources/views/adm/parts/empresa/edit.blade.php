<h3 class="title">{{$title}}</h3>

<section class="mt-3">
    <div class="container-fluid">
        @include('adm.parts.empresa.elemento.' . $seccion)
    </div>
</section>
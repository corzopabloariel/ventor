<div class="wrapper-producto">
    <div class="container py-5">
        <div class="row productos">
            <?php if(count($datos["productos"]) == 0): ?>
            <div class="col-12">
                <p class="mb-0 text-center title text-uppercase">Sin resultado</p>
            </div>
            <?php else: ?>
                <?php $__currentLoopData = $datos["productos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(URL::to('producto/' . $c['id'])); ?>" class="col-12 mb-2 col-md-6 col-lg-3">
                        <div>
                            <?php
                            $codigo_ima = $c["codigo_ima"];
                            $image = "IMAGEN/{$codigo_ima[0]}/{$codigo_ima}.jpg";
                            
                            ?>
                            <img src="<?php echo e(asset($image)); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                        </div>
                        <p class="mb-0"><?php echo e($c["stmpdh_art"]); ?></p>
                        <p class="mb-1 text-truncate"><?php echo e($c->modelo["modelo_y_a"]); ?></p>
                        <p class="mb-0" style="height: 66px; overflow: hidden;"><?php echo e($c["stmpdh_tex"]); ?></p>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>

        <div class="row d-flex justify-content-center">
            <?php if(isset($datos["paraID"])): ?>
                <?php echo e($datos["productos"]->appends( [ "para" => $datos["paraID"] ] )->links()); ?>

            <?php else: ?>
                <?php echo e($datos["productos"]->links()); ?>

            <?php endif; ?>
        </div>
        
    </div>
</div>
<?php $__env->startPush("scripts_distribuidor"); ?>

<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/productos/buscar.blade.php ENDPATH**/ ?>
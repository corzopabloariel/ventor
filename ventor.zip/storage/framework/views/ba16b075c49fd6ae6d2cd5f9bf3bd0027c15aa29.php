<div class="wrapper-contacto py-5">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-4">
                <h3 class="title mb-3">Ventor</h3>
                <ul class="list-unstyled info mb-0">
                    <li class="d-flex align-items-start">
                        <i class="fas fa-map-marker-alt"></i>
                        <div class="ml-2">
                            <p class="mb-0"><?php echo $datos["empresa"]["domicilio"]["calle"]; ?> <?php echo $datos["empresa"]["domicilio"]["altura"]; ?></p>
                            <p class="mb-0">Ciudad Autónoma de Buenos Aires</p>
                        </div>
                    </li>
                    <li class="d-flex align-items-start">
                        <i class="fas fa-phone-volume"></i>
                        <div class="ml-2">
                            <?php $__currentLoopData = $datos["empresa"]["telefono"]["tel"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a title="<?php echo e($t); ?>" class="text-truncate d-block" href="tel:<?php echo e($t); ?>"><?php echo $t; ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                    <li class="d-flex align-items-start">
                        <i class="far fa-envelope"></i>
                        <div class="ml-2">
                            <?php $__currentLoopData = $datos["empresa"]["email"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a title="<?php echo e($e); ?>" class="text-truncate d-block" href="mailto:<?php echo $e; ?>" target="blank"><?php echo $e; ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-8">
                <form action="<?php echo e(url('/form/contacto')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="col-12 col-md-6">
                            <input placeholder="Nombre" required type="text" value="<?php echo e(old('nombre')); ?>" name="nombre" class="form-control">
                        </div>
                        <div class="col-12 col-md-6">
                            <input placeholder="Apellido" required type="text" value="<?php echo e(old('apellido')); ?>" name="apellido" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-12">
                            <input placeholder="Email *" required type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control">
                        </div>
                        <div class="col-lg-6 col-12">
                            <input placeholder="Teléfono" type="phone" name="telefono" value="<?php echo e(old('telefono')); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <textarea name="mensaje" required rows="5" placeholder="Mensaje" class="form-control"><?php echo e(old('mensaje')); ?></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-12">
                            <div class="g-recaptcha" data-sitekey="6Lf8ypkUAAAAAKVtcM-8uln12mdOgGlaD16UcLXK"></div>
                        </div>
                        <div class="col-lg-6 col-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="1" name="terminos" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">
                                Acepto los términos y condiciones de privacidad
                            </label>
                        </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <button type="submit" class="btn px-5 text-white text-uppercase">enviar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script src='https://www.google.com/recaptcha/api.js'></script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/contacto.blade.php ENDPATH**/ ?>
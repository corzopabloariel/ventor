<div class="wrapper-contacto py-5">
    <div class="container mb-5">
        <h3 class="title text-uppercase" style="font-size: 32px; color: #595959; font-weight: 200">Sede ciudad de buenos aires</h3>
        <div class="row numeros">
            <?php $__currentLoopData = $datos["numeros"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($n["is_vendedor"] == 0): ?>
                <?php
                $n["email"] = json_decode($n["email"], true);
                ?>
                <div class="col-12 col-md-4 col-lg-3 d-flex align-items-stretch mt-2">
                    <article class="article w-100">
                        <p class="title text-uppercase"><?php echo e($n["nombre"]); ?></p>
                        <p class="title"><?php echo e($n["persona"]); ?></p>
                        <?php $__currentLoopData = $n["email"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="text-truncate"><a href="mailto:<?php echo e($e); ?>" target="_blank"><?php echo $e; ?></a></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <p><strong>Interno</strong> <?php echo e($n["interno"]); ?></p>
                        <?php if(!empty($n["celular"])): ?>
                            <p><strong>Celular</strong> <?php echo e($n["celular"]); ?></p>
                        <?php endif; ?>
                    </article>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="container-fluid mb-2">
        <div class="row">
            <div class="col-12 px-0">
                <iframe src="https://www.google.com/maps/d/embed?mid=1jX6Gl5rvxwMRNP-QFoWdofQHGxWr5zce" class="w-100 border-0" height="480"></iframe>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-4">
                <h3 class="title mb-3">Ventor</h3>
                <ul class="list-unstyled info mb-0">
                    <li class="d-flex align-items-start">
                        <i class="fas fa-map-marker-alt"></i>
                        <div class="ml-2">
                            <p class="mb-0"><?php echo $datos["empresa"]["domicilio"]["calle"]; ?> <?php echo $datos["empresa"]["domicilio"]["altura"]; ?></p>
                            <p class="mb-0">Ciudad Autónoma de Buenos Aires</p>
                        </div>
                    </li>
                    <li class="d-flex align-items-start">
                        <i class="fas fa-phone-volume"></i>
                        <div class="ml-2">
                            <?php $__currentLoopData = $datos["empresa"]["telefono"]["tel"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a title="<?php echo e($t); ?>" class="text-truncate d-block" href="tel:<?php echo e($t); ?>"><?php echo $t; ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                    <li class="d-flex align-items-start">
                        <i class="far fa-envelope"></i>
                        <div class="ml-2">
                            <?php $__currentLoopData = $datos["empresa"]["email"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a title="<?php echo e($e); ?>" class="text-truncate d-block" href="mailto:<?php echo $e; ?>" target="_blank"><?php echo $e; ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-8">
                <form action="<?php echo e(url('/form/contacto')); ?>" novalidate id="form" onsubmit="event.preventDefault(); enviar(this);" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="row justify-content-center">
                        <div class="col-12 col-md-6">
                            <label for="mandar">Enviar a</label>
                            <select name="mandar" id="mandar" class="form-control">
                            <option>ventor@ventor.com.ar</option>
                            <?php $__currentLoopData = $datos["numeros"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <optgroup label="<?php echo e($n['nombre'] . ' - ' . $n['persona']); ?>">
                                    <?php $__currentLoopData = $n["email"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option><?php echo $e; ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <input placeholder="Nombre *" required type="text" value="<?php echo e(old('nombre')); ?>" name="nombre" class="form-control">
                        </div>
                        <div class="col-12 col-md-6">
                            <input placeholder="Apellido" type="text" value="<?php echo e(old('apellido')); ?>" name="apellido" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-12">
                            <input placeholder="Email *" required type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control">
                        </div>
                        <div class="col-lg-6 col-12">
                            <input placeholder="Teléfono" type="phone" name="telefono" value="<?php echo e(old('telefono')); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <textarea name="mensaje" required rows="5" placeholder="Mensaje *" class="form-control"><?php echo e(old('mensaje')); ?></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-12">
                            <div class="g-recaptcha" data-sitekey="6Lf8ypkUAAAAAKVtcM-8uln12mdOgGlaD16UcLXK"></div>
                        </div>
                        <div class="col-lg-6 col-12">
                        <div class="form-check">
                            <input class="form-check-input" required data-placeholder="Términos y condiciones" type="checkbox" value="1" name="terminos" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">
                                Acepto los términos y condiciones de privacidad
                            </label>
                        </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <button type="submit" class="btn px-5 text-white text-uppercase">enviar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script src='https://www.google.com/recaptcha/api.js'></script>

<script>

function zfill(number, width) {
    var numberOutput = Math.abs(number); /* Valor absoluto del número */
    var length = number.toString().length; /* Largo del número */ 
    var zero = "0"; /* String de cero */  
    
    if (width <= length) {
        if (number < 0) {
             return ("-" + numberOutput.toString()); 
        } else {
             return numberOutput.toString(); 
        }
    } else {
        if (number < 0) {
            return ("-" + (zero.repeat(width - length)) + numberOutput.toString()); 
        } else {
            return ((zero.repeat(width - length)) + numberOutput.toString()); 
        }
    }
}

validar = function(t, marca = true, visible = true) {
    let flag = 1;
    $(t).find('*[required]').each(function() {
        if($(this).is(":visible")) {
            flagI = true;
            if($(this).attr("type") !== undefined) {
                if($(this).attr("type") == "file" || $(this).attr("type") == "date")
                    flagI = false;
            }
            if(flagI) {
                if($(this).is(":invalid") || $(this).val() == "") {
                    flag = 0;
                    if(marca) $(this).addClass("has-error");
                }
            }
        }
    });
    return flag;
};
validarSTRING = function(t) {
    let string = "";
    $(t).find('*[required]').each(function() {
        if($(this).is(":invalid") || $(this).val() == "") {
            flag = true;
            if($(this).attr("type") !== undefined) {
                if($(this).attr("type") == "file" || $(this).attr("type") == "date")
                    flag = false;
            }
            if(flag) {
                if($(this).is(":invalid") || $(this).val() == "") {
                    if(string != "") string += ", ";
                    if($(this).attr("placeholder") === undefined)
                        string += $(this).data("placeholder");
                    else {
                        t = $(this).attr("placeholder");
                        if(t.indexOf("*") >= 0)
                            t = t.replace(" *","");
                        string += t;
                    }
                }
            }
        }
    });
    return string;
}
enviar = function(t) {
    if(!validar($("#form"))) {
        str = validarSTRING($("#form"));
        alertify.notify(`Complete ${str} para enviar`, 'warning');
        return false;
    }
    document.getElementById("form").submit();
}

</script>

<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/contacto.blade.php ENDPATH**/ ?>
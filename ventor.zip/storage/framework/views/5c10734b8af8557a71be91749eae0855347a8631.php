
<div class="wrapper-formulario py-5 border-top-0 bg-white">
    <div class="container">
        <h3 class="title text-center">Consulta general</h3>
        <p class="text-center">Contáctanos y te brindaremos toda la información que necesites</p>

        <div class="row justify-content-center">
            <div class="col-12 col-md-8 col-lg-7">
                <form action="<?php echo e(url('/form/consulta')); ?>" novalidate id="form" onsubmit="event.preventDefault(); enviar(this);" method="post">
                <?php echo csrf_field(); ?>
                    <div id="formulario"></div>
                    <div class="row mt-3">
                        <div class="col-12 col-md-6">
                            <div class="g-recaptcha" data-sitekey="6LeFv6IUAAAAAGE-MtiFauHZVvNN3CEjpD71ZJT1"></div>
                        </div>
                        <div class="col-12 col-md-6 d-flex align-items-center">
                            <div class="form-check">
                                <input required class="form-check-input" type="checkbox" data-placeholder="TÉRMINOS Y CONDICIONES" value="1" name="terminos" id="defaultCheck1">
                                <label class="form-check-label" for="defaultCheck1">
                                    Acepto los términos y condiciones de privacidad
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <button type="submit" class="btn text-uppercase d-block mx-auto text-white px-5">enviar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush("scripts_distribuidor"); ?>
<script src='https://www.google.com/recaptcha/api.js'></script>
<script>
window.pyrus = new Pyrus("formulario_general");
$("#formulario").html(window.pyrus.formulario());
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/atencion/consulta.blade.php ENDPATH**/ ?>
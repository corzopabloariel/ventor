<?php if(auth()->guard('client')->check()): ?>
    <div id="wrapper-header"></div>
<?php else: ?>
    <div id="wrapper-header"></div>
<?php endif; ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/general/header.blade.php ENDPATH**/ ?>
<div class="wrapper-formulario bg-white border-top-0 py-5">
    <div class="container">
        <h2 class="title">Registro</h2>
        <form action="<?php echo e(route('registro')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row justify-content-center mt-4">
                <div class="col-12 col-md-8" id="formulario"></div>
            </div>
            <div class="row justify-content-center">
                <div class="col-12 col-md-8">
                    <button class="btn btn-primary text-uppercase">registrarse</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->startPush("scripts_distribuidor"); ?>
<script>
    window.pyrus = new Pyrus("formulario_registro");
    $("#formulario").html(window.pyrus.formulario());

</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/registro.blade.php ENDPATH**/ ?>
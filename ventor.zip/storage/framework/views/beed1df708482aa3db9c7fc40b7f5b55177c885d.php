<!DOCTYPE html>
<html>
<body>
    <p><strong>NRO DE CLIENTE:</strong> <?php echo e($nroCliente); ?></p>
    <p><strong>RAZÓN:</strong> <?php echo e($razon); ?></p>
    <p><strong>FECHA:</strong> <?php echo e($fecha); ?></p>
    <p><strong>IMPORTE:</strong> <?php echo e($importe); ?></p>
    <p><strong>BANCO:</strong> <?php echo e($banco); ?> - <?php echo e($sucursal); ?></p>
    <p><strong>FACTURAS:</strong> <?php echo e($facturas); ?></p>
    <p><strong>DESCUENTO:</strong> <?php echo e($descuento); ?></p>
</body>
</html><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/form/pago.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<body>
    <p><strong>NOMBRE:</strong> <?php echo e($nombre); ?> <?php echo e($apellido); ?></p>
    <p><strong>E-MAIL:</strong> <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>
    <p><strong>TELÉFONO:</strong> <?php echo e($telefono); ?></p>
    <p><strong>MENSAJE:</strong> <?php echo e($mensaje); ?></p>
</body>
</html><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/form/contacto.blade.php ENDPATH**/ ?>
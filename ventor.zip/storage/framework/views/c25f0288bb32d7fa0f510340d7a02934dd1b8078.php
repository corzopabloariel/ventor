<!DOCTYPE html>
<html>
<body>
    <?php echo e($mensaje[0]); ?><br/>
    <?php echo e($mensaje[1]); ?>

</body>
</html><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/form/pedido.blade.php ENDPATH**/ ?>
<?php echo e($mensaje[0]); ?>

<?php echo e($mensaje[1]); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/form/pedido.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<body>
    <?php echo e($mensaje); ?>

</body>
</html><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/form/pedido.blade.php ENDPATH**/ ?>
<div class="wrapper-categorias bg-white">
    <div class="container">
        <div class="row justify-content-center buscador">
            <div class="col-12 col-md-6">
                <form class="position-relative d-flex" action="<?php echo e(url('/buscador/body')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn"><i class="fas fa-search"></i></button>
                    <input placeholder="Buscar producto..." type="text" name="buscar" id="" class="form-control">
                </form>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-12 col-md-10">
                <div class="row justify-content-center">
                    <?php $__currentLoopData = $datos['categorias']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-4 col-lg-3 my-3 wrapper-link wow zoomIn">
                        <a href="<?php echo e(URL::to('productos/' . $c['id'])); ?>">
                            <div>
                                <img style="filter:<?php echo e($c['hsl']); ?>" src="<?php echo e(asset($c['image'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" alt="<?php echo e($c['nombre']); ?>">
                            </div>
                            <p class="mb-0 text-center"><?php echo e($c['nombre']); ?></p>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush("scripts_distribuidor"); ?>
<script>
    $(document).ready(function() {
        $('.wrapper-link a:nth-child(2n + 1)').jAnimate('', function(){
            console.log('animation was finished');
        });
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/productos/index.blade.php ENDPATH**/ ?>
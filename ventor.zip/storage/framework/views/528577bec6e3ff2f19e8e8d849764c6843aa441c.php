<?php
$arr = ["1" => "Cuenta ADM","2" => "Cuenta Vendedor","11" => "Cuenta Ventor"];
?>
<div class="d-flex align-items-center justify-content-center" style="height: 100vh;">
    <div>
        <h1>Bienvenido<br/><?php echo e(Auth::user()["name"]); ?></h1>
        <?php if(Auth::user()["is_admin"] == 2): ?>
            <?php if(strpos(Auth::user()["username"], "EMP_") !== false): ?>
            <p class="m-0"><?php echo e($arr[11]); ?></p>
            <?php else: ?>
            <p class="m-0"><?php echo e($arr[Auth::user()["is_admin"]]); ?></p>
            <?php endif; ?>
        <?php else: ?>
        <p class="m-0"><?php echo e($arr[Auth::user()["is_admin"]]); ?></p>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/adm/parts/index.blade.php ENDPATH**/ ?>
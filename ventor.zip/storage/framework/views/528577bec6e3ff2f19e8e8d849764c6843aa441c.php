<?php
$arr = ["1" => "Cuenta ADM","2" => "Cuenta Vendedor","11" => "Cuenta Ventor"];
?>
<div class="d-flex align-items-center justify-content-center" style="height: 100vh;">
    <div>
        <h1>Bienvenido<br/><?php echo e(Auth::user()["name"]); ?></h1>
        <p class="m-0"><?php echo e($arr[Auth::user()["is_admin"]]); ?></p>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/adm/parts/index.blade.php ENDPATH**/ ?>
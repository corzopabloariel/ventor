<div class="wrapper-producto">
    <div class="container pb-4 pt-2 navegador">
        <a href="<?php echo e(URL::to('productos')); ?>">Productos</a>
        <?php $__currentLoopData = $datos["nombres"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($n["parte"])): ?>
                <a href="<?php echo e(URL::to('productos/' . $n['id']) . '/parte'); ?>"><?php echo e($n["nombre"]); ?></a>
            <?php else: ?>
                <a href="<?php echo e(URL::to('productos/' . $n['id'])); ?>"><?php echo e($n["nombre"]); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="container pb-5">
        <div class="row">
            <div class="col-12 col-md-4">
                <button class="btn text-uppercase d-block d-sm-none rounded-0 mb-2" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample" style="background: #0099D6">
                    categorias<i class="fas fa-sort-amount-down ml-2"></i>
                </button>
                <div class="sidebar collapse dont-collapse-sm" id="collapseExample">
                    <div class="sidebar">
                        <?php $__currentLoopData = $datos["menu"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h5 class="title mb-1 position-relative <?php if(isset($dato['active'])): ?> active <?php endif; ?>" data-id="<?php echo e($dato['id']); ?>" style="color:<?php echo e($dato['color']); ?>">
                                <a href="<?php echo e(URL::to('productos/'. $dato['id'])); ?>"><?php echo e($dato["nombre"]); ?></a>
                                <i data-tipo="close" class="fas fa-angle-down"></i>
                                <i data-tipo="open" class="fas fa-angle-right"></i>
                            </h5>
                            <?php if(count($dato["hijos"]) > 0): ?>
                                <ul data-nivel="<?php echo e($dato['tipo']); ?>" class="list-group list-group-flush">
                                <?php $__currentLoopData = $dato["hijos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as ${"dato_". $dato["id"]}): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make('page.parts.productos._menuItem', ["dato" => ${"dato_". $dato["id"]}], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            
            <div class="col-12 col-md-8">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <img src="<?php echo e(asset($datos['producto']['image'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100 border" />
                    </div>
                    <div class="col-12 col-md-6">
                        <p class="codigo mb-1"><?php echo e($datos["producto"]["stmpdh_art"]); ?></p>
                        <p class="para text-uppercase mb-1">para <?php echo e($datos["producto"]["modelo_id"]); ?></p>
                        <div class="title"><?php echo $datos["producto"]["stmpdh_tex"]; ?></div>
                        <div class="table-responsive">
                            <table class="table w-100">
                                <tbody>
                                    <tr>
                                        <td class="title">Código</td>
                                        <td><?php echo e($datos["producto"]["stmpdh_art"]); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="title">Marca</td>
                                        <td><?php echo e($datos["producto"]->modelo->marca["web_marcas"]); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="title">Modelo</td>
                                        <td><?php echo e($datos["producto"]->modelo["modelo_y_a"]); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td class="title">Cantidad Envasada</td>
                                        <td><?php echo e($datos["producto"]["cantminvta"] == 1 ? $datos["producto"]["cantminvta"] . " unidad" : $datos["producto"]["cantminvta"] . " unidades"); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/productos/producto.blade.php ENDPATH**/ ?>
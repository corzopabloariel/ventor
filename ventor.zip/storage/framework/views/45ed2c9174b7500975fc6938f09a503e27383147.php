<?php $__env->startSection('body'); ?>
    <?php echo $__env->make($view, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $("body").on("click",".alert button.close", function() {
            $(this).closest(".alert").remove();
        });
    });
</script>
<?php echo $__env->yieldPushContent('scripts_distribuidor'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('page.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/distribuidor.blade.php ENDPATH**/ ?>
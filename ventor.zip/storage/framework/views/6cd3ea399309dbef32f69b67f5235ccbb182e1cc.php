<!DOCTYPE html>
<html>
<body>
    <p><strong>EMPRESA O NOMBRE:</strong> <?php echo e($empresa); ?></p>
    <p><strong>E-MAIL:</strong> <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></p>
    <p><strong>TELÉFONO:</strong> <?php echo e($telefono); ?></p>
    <p><strong>LOCALIDAD:</strong> <?php echo e($localidad); ?></p>
    <p><strong>MENSAJE:</strong> <?php echo e($mensaje); ?></p>
</body>
</html><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/form/consulta.blade.php ENDPATH**/ ?>
<?php $__env->startPush("styles"); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<link href="<?php echo e(asset('css/alertifyjs/alertify.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<div class="wrapper-pedido py-5">
    <div class="container">
        <?php if(isset($datos["carrito"])): ?>
            <h2 class="title mb-3 text-uppercase">carrito (<span id="cantProductos">0</span>)</h2>
        <?php else: ?>
        <div class="row justify-content-center mt-2 mb-5">
            <div class="col-12 col-md-6">
                <form action="<?php echo e(url('pedido')); ?>" method="post" class="buscador position-relative">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-link position-absolute"><i class="fas fa-search"></i></button>
                    <input type="text" name="buscar" value="<?php if(!empty($datos['buscar'])): ?> <?php echo e($datos['buscar']); ?> <?php endif; ?>" class="form-control" placeholder="Buscar código, parte, marca, nombre">
                </form>
            </div>
        </div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table w-100" id="tabla">
                <thead>
                    <?php if(!isset($datos["carrito"])): ?>
                    <th style="width:100px;"></th>
                    <th>Producto</th>
                    <th>Categoría</th>
                    <th class="text-center">Unidad de Venta</th>
                    <th class="text-right">Precio unitario</th>
                    <th>cantidad de productos</th>
                    <th></th>
                    <?php else: ?>
                    <th style="width:100px;"></th>
                    <th>Producto</th>
                    <th>Categoría</th>
                    <th class="text-center">Unidad de Venta</th>
                    <th class="text-right">Precio unitario</th>
                    <th class="text-center">cantidad de productos</th>
                    <th class="text-right">subtotal</th>
                    <th class="text-center">eliminar</th>
                    <?php endif; ?>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datos["productos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!isset($datos["carrito"])): ?>
                    
                    <tr class="" data-id="<?php echo e($p['id']); ?>" data-precio="<?php echo e($p['precio']); ?>">
                        <td style="width:100px;">
                            <?php
                            $image = asset("IMAGEN/{$p["codigo_ima"][0]}/{$p["codigo_ima"]}.jpg");
                            ?>
                            <img class="border w-100" src="<?php echo e($image); ?>" onerror="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'"/>
                        </td>
                        <td>
                            <p class="mb-0"><?php echo e($p["stmpdh_art"]); ?></p>
                            <p class="mb-0"><?php echo $p->parte_id(); ?></p>
                            <p class="mb-0"><?php echo $p["stmpdh_tex"]; ?></p>
                        </td>
                        <td><?php echo $p->parte_id(); ?></td>
                        <td class="text-center"><?php echo e($p["cantminvta"]); ?></td>
                        <td class="text-right"><?php echo e("$ " . $p->getPrecio()); ?></td>
                        <td data-cantidad style="width:150px"><input pattern="[0-9]+" onchange="cambio(this)" type="number" class="form-control text-center" name="" min="<?php echo e($p['cantminvta']); ?>" value="0" step="<?php echo e($p['cantminvta']); ?>" id=""></td>
                        <td class="text-center"><button onclick="pedido(this)" type="button" class="btn btn-secondary text-uppercase">pedir</button></td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <?php if(isset($datos["carrito"])): ?>
        <div class="row mt-3">
            <div class="col-12 col-md-7 obs">
                <p>Observaciones</p>
                <textarea name="observaciones" id="observaciones" rows="3" class="form-control" placeholder="Observaciones"></textarea>
            </div>
            <div class="col-12 col-md-5 valor">
                
                <p class="total border-bottom border-dark mb-1 d-flex w-100 align-items-center justify-content-between">Total <span id="total">$ 0</span></p>
                <p style="color: #C01939; font-size: 13px mb-0">El total no incluye IVA ni impuestos internos</p>

                <div class="row">
                    <div class="col-12 col-md-6">
                        <button onclick="window.location='<?php echo e(route('pedido')); ?>'" type="button" class="btn btn-block text-center px-3 text-uppercase btn-outline-secondary">continuar pedido</button>
                    </div>
                    <div class="col-12 col-md-6">
                        <button onclick="pedir(this)" type="button" class="btn btn-block text-center px-3 text-uppercase btn-secondary">realizar pedido</button>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="row col-12 justify-content-center">
            <div class="overflow-auto">
                <?php echo e($datos["productos"]->onEachSide(5)->links()); ?>

            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
<script src="<?php echo e(asset('js/alertify.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-input-spinner.js')); ?>"></script>
<script>
    $(document).ready(function() {
        
        if($("input[type='number']").length) {
            let config = {
                decrementButton: '<i class="fas fa-minus"></i>',
                incrementButton: '<i class="fas fa-plus"></i>',
                buttonsClass: "btn-outline-secondary btn-sm",
                buttonsWidth: "1.5rem",
            }
            $( "input[type='number']" ).inputSpinner(config);
        }
    });
    formatter = new Intl.NumberFormat('es-AR', {
        style: 'currency',
        currency: 'ARS',
    });

    if(localStorage.productos !== undefined) {
        window.productos = JSON.parse(localStorage.productos);
        window.normal = 1;
        <?php if(isset($datos["carrito"])): ?>
        for(let id in window.productos) {
            let promise = new Promise(function (resolve, reject) {
                let url = `<?php echo e(url('productoSHOW/${id}')); ?>`;
                var xmlHttp = new XMLHttpRequest();
                xmlHttp.responseType = 'json';
                xmlHttp.open( "GET", url, true );
                xmlHttp.onload = function() {
                    resolve(xmlHttp.response);
                }
                xmlHttp.send( null );
            });

            promiseFunction = () => {
                promise
                    .then(function(data) {
                        addRow(data);
                    })
            };
            promiseFunction();
        }

        <?php endif; ?>
        for(let x in window.productos) {
            $(`table *[data-id="${x}"]`).removeClass("d-none");
            $(`table *[data-id="${x}"]`).find("*[data-cantidad] input").val(window.productos[x].cantidad).trigger("change");
        }
        delete window.normal;
        if(Object.keys(window.productos).length > 0) {
            if(!$("nav [data-carrito] > a > span").length) 
                $("nav [data-carrito] > a").append(`<span class="ml-1">(${Object.keys(window.productos).length})</span>`);
            if($("#cantProductos").length)
                $("#cantProductos").text(Object.keys(window.productos).length);
        }
    }
    /** ------------------------------------- */
    addRow = function(data) {
        
        $("#tabla tbody").append(`<tr data-id="${data.id}" data-precio="${data.precio}">` +
            `<td style="">` +
                `<img class="border w-100" src="${data.image}" onerror="this.src=''"/>` +
            `</td>` +
            `<td>${data.stmpdh_tex}</td>` +
            `<td>${data.parte_id}</td>` +
            `<td class="text-center">${data.cantminvta}</td>` +
            `<td class="text-right">$ ${data.precioF}</td>` +
            `<td data-cantidad style="width: 140px;"><input onchange="cambio(this)" type="number" class="form-control text-right" name="cantidad[]" min="${data.cantminvta}" step="${data.cantminvta}"></td>` +
            `<td class="text-right" data-subtotal class="text-right">$ </td>` +
            `<td class="text-center"><button onclick="eliminar(this)" type="button" class="btn btn-link text-uppercase" style="color:#9B9B9B"><i class="far fa-times-circle"></i></button></td>` +
        `</tr>`);
        $("#tabla tbody").find("tr:last-child input[type='number']").val(window.productos[data.id]["cantidad"]).trigger("change");
        if($("#tabla tbody").find("tr:last-child input[type='number']").length) {
            $("#tabla tbody").find("tr:last-child input[type='number']").inputSpinner({
                decrementButton: '<i class="fas fa-minus"></i>',
                incrementButton: '<i class="fas fa-plus"></i>',
                buttonsClass: "btn-outline-secondary btn-sm",
                buttonsWidth: "1.5rem",
            });
        }
    };

    pedido = function(t) {
        let id = $(t).closest("tr").data("id");
        let precio = $(t).closest("tr").data("precio");
        let cantidad = $(t).closest("tr").find("*[data-cantidad] input").val();
        if(window.productos === undefined)
            window.productos = {};
        if(window.productos[id] === undefined)
            window.productos[id] = {cantidad: 0,precio:precio};
        window.productos[id].cantidad = cantidad;

        localStorage.setItem("productos",JSON.stringify(window.productos));
        alertify.success(`${window.productos[id].cantidad} u. seleccionadas`);

        
        if(Object.keys(window.productos).length > 0) {
            if(!$("nav [data-carrito] > a > span").length) 
                $("nav [data-carrito] > a").append(`<span class="ml-1">(${Object.keys(window.productos).length})</span>`);
            else
                $("nav [data-carrito] > a > span").text(`(${Object.keys(window.productos).length})`);
        }
    }
    eliminar = function(t) {
        let id = $(t).closest("tr").data("id");
        
        alertify.confirm("ATENCIÓN","¿Eliminar registro?",
            function(){
                let precio = parseFloat($(t).closest("tr").data("precio"));
                let cantidad = parseInt($(t).closest("tr").find("td[data-cantidad] input").val());
                window.sumaTotal.TOTAL -= precio * cantidad;
                if($("#subtotal").length) {
                    $("#subtotal").text(formatter.format(window.sumaTotal.TOTAL));
                    $("#bonificacion").text(formatter.format(window.sumaTotal.TOTAL * window.data.descuento * (-1)));
                    $("#total").text(formatter.format(window.sumaTotal.TOTAL + (window.sumaTotal.TOTAL * window.data.descuento * (-1))));
                }
                $(t).closest("tr").remove();
                delete window.productos[id];
                localStorage.setItem("productos",JSON.stringify(window.productos));

                if($("#cantProductos").length)
                    $("#cantProductos").text(Object.keys(window.productos).length);
                $("nav [data-carrito] > a > span").text(`(${Object.keys(window.productos).length})`);
                if(Object.keys(window.productos).length == 0) {
                    if($("nav [data-carrito] > a > span").length) 
                        $("nav [data-carrito] > a > span").remove();
                }
            },
            function() {}
        ).set('labels', {ok:'Confirmar', cancel:'Cancelar'});
    }
    function cambio(t) {
        let id = parseInt($(t).closest("tr").data("id"));
        if($(t).closest("tr").data("precio") == "") {
            $(t).closest("tr").find("*[data-subtotal]").text(formatter.format(0));
            return false;
        }
        let precio = parseFloat($(t).closest("tr").data("precio"));
        let cantidad = parseInt($(t).val());
        console.log(precio)

        let step = parseInt($(t).attr("step"));
        if(cantidad % step === 0) {
            if(window.sumaTotal === undefined) {
                window.sumaTotal = {};
                window.sumaTotal.TOTAL = 0.0;
            }
            if(window.sumaTotal[id] !== undefined)
                window.sumaTotal.TOTAL -= precio * window.sumaTotal[id];
            if(window.sumaTotal[id] === undefined)
                window.sumaTotal[id] = 0;    
            window.sumaTotal[id] = cantidad;
            /*------ RESTO PRIMERO */
            if(window.normal === undefined)
            
            /*------ SUMO EL NUEVO VALOR */
            window.sumaTotal.TOTAL += precio * cantidad;
            window.productos[id].cantidad = cantidad;
            localStorage.setItem("productos",JSON.stringify(window.productos));

            $(t).closest("tr").find("*[data-subtotal]").text(formatter.format(precio * cantidad));
        } else {
            alertify.notify(`Cantidad no permitida. Solo múltiplos de ${step}`, 'warning');
            $(t).select();
        }
        if($("#subtotal").length) {
            $("#subtotal").text(formatter.format(window.sumaTotal.TOTAL));
            $("#bonificacion").text(formatter.format(window.sumaTotal.TOTAL * window.data.descuento * (-1)));
            $("#total").text(formatter.format(window.sumaTotal.TOTAL + (window.sumaTotal.TOTAL * window.data.descuento * (-1))));
        }
    }
    pedir = function(t) {
        alertify.confirm("ATENCIÓN","Está por procesar el pedido. ¿Confirma acción?",
            function() {
                let request = new XMLHttpRequest();
                let formData = new FormData();
                let url = `<?php echo e(url('pedidoCliente')); ?>`;

                request.responseType = 'json';
                formData.append("_token","<?php echo e(csrf_token()); ?>");
                formData.append("idUsuario",window.data.id);
                formData.append("observaciones",$("#observaciones").val());
                
                formData.append("pedido", JSON.stringify(window.productos));
                
                request.open("POST", url);
                request.onload = function() {
                    localStorage.removeItem("productos");
                    
                    //data = request.response;
                    let url = `<?php echo e(route('pedido')); ?>`;
                    alertify.success(`Pedido realizado. Espere`);
                    $("body input,body button").attr("disabled",true);
                    setTimeout(() => {
                        window.location = url;
                    }, 5000);
                }
                request.send(formData);
            },
            function() {}
        ).set('labels', {ok:'Si', cancel:'No'});
    };
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/pedido.blade.php ENDPATH**/ ?>
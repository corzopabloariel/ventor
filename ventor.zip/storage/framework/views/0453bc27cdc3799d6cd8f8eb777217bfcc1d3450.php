<div id="carouselExampleIndicators" class="carousel slide wrapper-slider" data-ride="carousel">
    <ol class="carousel-indicators">
        <?php for($i = 0 ; $i < count($datos['slider']) ; $i++): ?>
            <?php if($i == 0): ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" class="active"></li>
            <?php else: ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>"></li>
            <?php endif; ?>
        <?php endfor; ?>
    </ol>
    <div class="carousel-inner">
        <?php for($i = 0 ; $i < count($datos['slider']) ; $i++): ?>
        <?php if($i == 0): ?>
            <div class="carousel-item active">
        <?php else: ?>
            <div class="carousel-item">
        <?php endif; ?>
            <img class="d-block w-100" src="<?php echo e(asset('' . $datos['slider'][$i]['image'])); ?>" >
            <div class="carousel-caption position-absolute w-100 h-100" style="top: 0; left: 0;">
                <div class="container position-relative h-100 d-flex align-items-center">
                    <div class="texto text-left">
                        <?php echo $datos['slider'][$i]['texto']; ?>

                        <?php if(!empty( $datos['slider'][$i]['link'] )): ?>
                        <a href="<?php echo e(URL::to($datos['slider'][$i]['link'])); ?>" style="background: #C1C0BD; padding: 10px 20px;" class="btn mt-2 text-white text-uppercase">ver <?php echo e($datos['slider'][$i]['link']); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endfor; ?>
    </div>
</div>
<div class="wrapper-novedades py-5">
    <div class="container">
        <h3 class="title text-uppercase text-center mb-4">¡novedades!</h3>
        <div class="row productos">
            <?php $__currentLoopData = $datos["novedades"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(asset($c['documento'])); ?>" download class="col-12 col-md-4">
                    <div>
                        <img src="<?php echo e(asset($c['image'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                    </div>
                    <?php echo $c["nombre"]; ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<div class="wrapper-categorias">
    <div class="container">
        <h3 class="title text-uppercase text-center">categorias</h3>
        <div class="row justify-content-center">
            <div class="col-12 col-md-10">
                <div class="row justify-content-center buscador">
                    <div class="col-12 col-md-6">
                        <form class="position-relative d-flex" action="<?php echo e(url('/buscador/home')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn"><i class="fas fa-search"></i></button>
                            <input placeholder="Buscar producto..." type="text" name="" id="" class="form-control">
                        </form>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <?php $__currentLoopData = $datos['categorias']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-4 col-lg-3 my-3 wrapper-link wow zoomIn">
                        <a href="<?php echo e(URL::to('productos/' . $c['id'])); ?>">
                            <div>
                                <img style="filter:<?php echo e($c['hsl']); ?>" src="<?php echo e(asset($c['image'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" alt="<?php echo e($c['nombre']); ?>">
                            </div>
                            <p class="mb-0 text-center"><?php echo e($c['nombre']); ?></p>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/index.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<body>
    <p><strong>NOMBRE Y APELLIDO:</strong> <?php echo e($nombre); ?></p>
    <p><strong>TELÉFONO:</strong> <?php echo e($telefono); ?></p>
    <p><strong>DOMICILIO:</strong> <?php echo e($domicilio); ?>, <?php echo e($localidad); ?></p>
    <p><strong>EMAIL:</strong> <?php echo e($email); ?></p>
    <br/>
    <?php
    $Arr_transmision = [ "nueva" => "Transmisión Nueva", "existente" => "Transmisión Existente" ];
    $Arr_correa = [ "v" => "Correas en V", "sincronica" => "Correas Sincrónicas" ];
    ?>
    <p><strong>TIPO DE TRANSMISIÓN:</strong> <?php echo e($Arr_transmision[$transmision]); ?></p>
    <p><strong>TIPO DE CORREAS:</strong> <?php echo e($Arr_correa[$correa]); ?></p>
    <br/>
    <p><strong>POTENCIA:</strong> <?php echo e($potencia); ?></p>
    <p><strong>FACTOR DE SERVICIO:</strong> <?php echo e($factor); ?></p>
    <p><strong>RPM POLEA MOTOR:</strong> <?php echo e($poleaMotor); ?></p>
    <p><strong>RPM POLEA CONDUCIDA:</strong> <?php echo e($poleaConducida); ?></p>
    
    <p><strong>ENTRE CENTRO:</strong></p>
    <ul>
        <li>MIN: <?php echo e($centroMin); ?></li>
        <li>MAX: <?php echo e($centroMax); ?></li>
    </ul>
    <br/>
    <p><strong>MENSAJE:</strong> <?php echo e($mensaje); ?></p>
    <br/>
    <p><strong>PREFERENCIA POR ALGÚN PERFIL:</strong> <?php echo e($perfil); ?></p>
</body>
</html><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/form/transmision.blade.php ENDPATH**/ ?>
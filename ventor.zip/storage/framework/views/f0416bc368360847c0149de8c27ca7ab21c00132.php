<div class="wrapper-descargas py-5">
    <div class="container">
        <h2 class="title text-uppercase">información adicional</h2>
        <h4>Descargas e instructivos</h4>

        <div class="row mt-3">
            <?php $__currentLoopData = $datos["descargas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-3 descarga d-flex justify-content-center">
                    <div class="d-inline-block">
                        <img style="width: 192px;" src="<?php echo e(asset($d['image'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-descarga.fw.png')); ?>'" class="border d-block" />
                        <p class="w-75 mx-auto mb-1 mt-2 text-center"><?php echo e($d["nombre"]); ?></p>
                        <div class="row">
                            <div class="col-6 text-right eye">
                                <a href="<?php echo e(asset($d['documento'])); ?>" target="blank"><i class="fas fa-eye"></i></a>
                            </div>
                            <div class="col-6 text-left download">
                                <a href="<?php echo e(asset($d['documento'])); ?>" download><i class="fas fa-download"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/descargas.blade.php ENDPATH**/ ?>
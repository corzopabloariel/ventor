<h3 class="title"><?php echo e($title); ?></h3>

<section class="mt-3">
    <div class="container-fluid">
        
    </div>
</section><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/adm/parts/empresa/numeros.blade.php ENDPATH**/ ?>
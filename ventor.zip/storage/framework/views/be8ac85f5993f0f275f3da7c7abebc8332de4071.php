<li class="list-group-item border-0">
    <span class="d-block position-relative  <?php if(isset($dato['active'])): ?> active <?php endif; ?>" data-id="<?php echo e($dato['id']); ?>">
        <?php if(isset($url)): ?>
        <a class="d-block" href="<?php echo e(URL::to('pedido/parte/' . $id . '/subparte/'. $dato['id'])); ?>"><?php echo e($dato["nombre"]); ?></a>
        <?php else: ?>
        <a class="d-block" href="<?php echo e(URL::to('productos/'. $dato['id']). '/parte'); ?>"><?php echo e($dato["nombre"]); ?></a>
        <?php endif; ?>
    </span>
    <?php if(count($dato["hijos"]) > 0): ?>
        <ul class="list-group list-group-flush">
        <?php $__currentLoopData = $dato["hijos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as ${"dato_". $dato["id"]}): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('page.parts.productos._menuItem', ["dato" => ${"dato_". $dato["id"]}], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</li><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/productos/_menuItem.blade.php ENDPATH**/ ?>
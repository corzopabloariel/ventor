<div class="wrapper-producto">
    <div class="container pb-4 pt-2 navegador">
        <a href="<?php echo e(URL::to('productos')); ?>">Productos</a>
        <?php $__currentLoopData = $datos["nombres"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(URL::to('productos/' . $n['id'])); ?>"><?php echo e($n["nombre"]); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="container pb-5">
        <div class="row">
            <div class="col-md-4">
                <div class="sidebar" id="collapseExample">
                    <div class="sidebar">
                        <?php $__currentLoopData = $datos["menu"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h5 class="title mb-1 position-relative <?php if(isset($dato['active'])): ?> active <?php endif; ?>" data-id="<?php echo e($dato['id']); ?>" style="color:<?php echo e($dato['color']); ?>">
                                <a href="<?php echo e(URL::to('productos/'. $dato['id'])); ?>"><?php echo e($dato["nombre"]); ?></a>
                                <i data-tipo="close" class="fas fa-angle-down"></i>
                                <i data-tipo="open" class="fas fa-angle-right"></i>
                            </h5>
                            <?php if(count($dato["hijos"]) > 0): ?>
                                <ul data-nivel="<?php echo e($dato['tipo']); ?>" class="list-group list-group-flush">
                                <?php $__currentLoopData = $dato["hijos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as ${"dato_". $dato["id"]}): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make('page.parts.productos._menuItem', ["dato" => ${"dato_". $dato["id"]}], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <?php if(count($datos["categorias"]) == 0): ?>
                <div class="row categorias"></div>
                <?php else: ?>
                <div class="row categorias">
                    <?php $__currentLoopData = $datos["categorias"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(URL::to('productos/' . $c['id'])); ?>" class="col-12 col-md-4">
                            <div>
                                <img src="<?php echo e(asset($c['image'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                            </div>
                            <p class="mb-0"><?php echo e($c["nombre"]); ?></p>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <?php if(count($datos["productos"]) == 0): ?>
                <div class="row productos"></div>
                <?php else: ?>
                <div class="row productos">
                    <?php $__currentLoopData = $datos["productos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(URL::to('producto/' . $c['link'])); ?>" class="col-12 col-md-4">
                            <div>
                                <img src="<?php echo e(asset($c['image'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                            </div>
                            <p class="mb-0"><?php echo e($c["codigo"]); ?></p>
                            <p class="mb-1 text-truncate"><?php echo e($c["modelo"]); ?></p>
                            <?php echo $c["nombre"]; ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/productos/familia.blade.php ENDPATH**/ ?>
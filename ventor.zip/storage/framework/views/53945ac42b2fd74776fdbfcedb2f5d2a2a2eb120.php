<div class="wrapper-producto">
    <div class="container pb-4 pt-2 navegador text-uppercase">
        <a href="<?php echo e(URL::to('productos')); ?>">Productos</a>
        <?php $__currentLoopData = $datos["nombres"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(URL::to('productos/' . $n['id'])); ?>"><?php echo e($n["nombre"]); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="container pb-5">
        <div class="row">
            <div class="col-md-5 col-lg-4">
                <button class="btn text-uppercase d-block d-sm-none rounded-0 mb-2" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample" style="background: #0099D6">
                    categorias<i class="fas fa-sort-amount-down ml-2"></i>
                </button>
                <div class="sidebar collapse dont-collapse-sm" id="collapseExample">
                    <div class="sidebar">
                        <?php $__currentLoopData = $datos["menu"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion md-accordion border-0" id="accordionEx" role="tablist" aria-multiselectable="true">
                            <div class="card border-0">
                                <div class="card-header bg-white p-0 border-bottom" role="tab" id="Hproductos<?php echo e($dato['id']); ?>">
                                    <h5 style="color:<?php echo e($dato['color']); ?>; cursor: pointer" class="mb-0 parte py-3" data-parent="#accordionEx" data-toggle="collapse" data-target="#productos<?php echo e($dato['id']); ?>" aria-expanded="<?php if(isset($dato['active'])): ?> true <?php else: ?> false <?php endif; ?>" aria-controls="productos<?php echo e($dato['id']); ?>">
                                        <a class="" href="<?php echo e(URL::to('productos/' . $dato['id'])); ?>">
                                            <?php echo e($dato["nombre"]); ?>

                                        </a>
                                        <i class="fas fa-angle-down rotate-icon float-right"></i>
                                    </h5>
                                </div>
                                <div id="productos<?php echo e($dato['id']); ?>" class="collapse <?php if(isset($dato['active'])): ?> show <?php endif; ?>" role="tabpanel" aria-labelledby="Hproductos<?php echo e($dato['id']); ?>" data-parent="#accordionEx">
                                    <div class="card-body p-0">
                                    <?php if(count($dato["hijos"]) > 0): ?>
                                        <ul data-nivel="<?php echo e($dato['tipo']); ?>" class="list-group list-group-flush subPartes">
                                        <?php $__currentLoopData = $dato["hijos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as ${"dato_". $dato["id"]}): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $__env->make('page.parts.productos._menuItem', ["dato" => ${"dato_". $dato["id"]}], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="col-md-7 col-lg-8">
                <?php if(count($datos["categorias"]) == 0): ?>
                <div class="row categorias"></div>
                <?php else: ?>
                <div class="row categorias">
                    <?php $__currentLoopData = $datos["categorias"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(URL::to('productos/' . $c['id'])); ?>" class="col-12 col-md-6 col-lg-4">
                            <div>
                                <img src="<?php echo e(asset($c['image'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                            </div>
                            <p class="mb-0"><?php echo e($c["nombre"]); ?></p>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <?php if(count($datos["productos"]) == 0): ?>
                <div class="row productos"></div>
                <?php else: ?>
                <div class="row">
                    <div class="col-12">
                        <form action="" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="d-flex align-items-baseline">
                                <select name="para" id="para" class="form-control">
                                    <option></option>
                                    <?php $__currentLoopData = $datos["para"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($datos["paraID"])): ?>
                                        <option <?php if($datos["paraID"] == $i): ?> selected <?php endif; ?> value="<?php echo e($i); ?>"><?php echo e($v); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($i); ?>"><?php echo e($v); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="btn btn-sm btn-secondary text-uppercase ml-2">filtrar</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row productos">
                    <?php $__currentLoopData = $datos["productos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(URL::to('producto/' . $c['id'])); ?>" class="col-12 mb-2 col-md-6 col-lg-4">
                            <div>
                                <?php
                                $codigo_ima = $c["codigo_ima"];
                                $image = "IMAGEN/{$codigo_ima[0]}/{$codigo_ima}.jpg";
                                
                                ?>
                                <img src="<?php echo e(asset($image)); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                            </div>
                            <p class="mb-0"><?php echo e($c["stmpdh_art"]); ?></p>
                            <p class="mb-1 text-truncate"><?php echo e($c->modelo["modelo_y_a"]); ?></p>
                            <p class="mb-0" style="height: 66px; overflow: hidden;"><?php echo e($c["stmpdh_tex"]); ?></p>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row d-flex justify-content-center">
                    <?php if(isset($datos["paraID"])): ?>
                        <?php echo e($datos["productos"]->appends( [ "para" => $datos["paraID"] ] )->links()); ?>

                    <?php else: ?>
                        <?php echo e($datos["productos"]->links()); ?>

                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush("scripts_distribuidor"); ?>
<script>
    $(document).ready(function() {
        $("#para").select2({
            theme: "bootstrap",
            placeholder: "Marca"
        });
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/productos/familia.blade.php ENDPATH**/ ?>
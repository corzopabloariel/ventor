<div class="wrapper-trabaje py-5">
    <div class="container">
        <h2 class="title text-uppercase">trabaje con nosotros</h2>
        <div class="row">
            <div class="col-12 col-md-4"></div>
            <div class="col-12 col-md-8" id="formulario"></div>
        </div>
    </div>
</div>
<?php $__env->startPush("scripts_distribuidor"); ?>
<script>
    window.pyrus = new Pyrus("formulario_recursos");
    $("#formulario").html(window.pyrus.formulario());

</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/trabaje.blade.php ENDPATH**/ ?>
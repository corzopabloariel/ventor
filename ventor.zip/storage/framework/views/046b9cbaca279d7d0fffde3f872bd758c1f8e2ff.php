<div id="carouselExampleIndicators" class="carousel slide wrapper-slider" data-ride="carousel">
    <ol class="carousel-indicators">
        <?php for($i = 0 ; $i < count($datos['slider']) ; $i++): ?>
            <?php if($i == 0): ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" class="active"></li>
            <?php else: ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>"></li>
            <?php endif; ?>
        <?php endfor; ?>
    </ol>
    <div class="carousel-inner">
        <?php for($i = 0 ; $i < count($datos['slider']) ; $i++): ?>
        <?php if($i == 0): ?>
            <div class="carousel-item active">
        <?php else: ?>
            <div class="carousel-item">
        <?php endif; ?>
            <img class="d-block w-100" src="<?php echo e(asset('' . $datos['slider'][$i]['image'])); ?>" >
            <div class="carousel-caption position-absolute w-100 h-100" style="top: 0; left: 0;">
                <div class="container position-relative h-100 d-flex align-items-center">
                    <div class="texto">
                        <?php echo $datos['slider'][$i]['texto']; ?>

                        <?php if(!empty( $datos['slider'][$i]['link'] )): ?>
                        <button style="background: #C1C0BD; padding: 10px 20px;" class="btn d-block text-white text-uppercase">ver <?php echo e($datos['slider'][$i]['link']); ?></button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endfor; ?>
    </div>
</div>

<div class="wrapper-empresa">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-7 col-lg-7 principal wow slideInUp">
                <?php echo $datos["contenido"]["texto"]; ?>

            </div>
            <div class="col-12 col-md-5 col-lg-5">
                <table class="w-100">
                <?php $__currentLoopData = $datos["contenido"]["numeros"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="wow fadeIn">
                        <td class="title">
                            <?php echo e($n["N"]); ?>

                        </td>
                        <td>
                            <?php echo e($n["T"]); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>

        <div class="row timeline my-5 wow">
            <div class="col-12 d-flex justify-content-center">
                <div class="w-100">
                    <div class="d-flex justify-content-center">
                        <?php $__currentLoopData = $datos["contenido"]["fechas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div onclick="change(this)" class="input" data-year="<?php echo e($f); ?>">
                            <span data-year="<?php echo e($f); ?>"></span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-12 col-md-7">
                            <div class="d-flex justify-content-center flex-column mt-3">
                                <?php $__currentLoopData = $datos["contenido"]["fechas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="text text-center d-none" data-year="<?php echo e($f); ?>">
                                    <?php echo $t; ?>

                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mision-vision">
            <div class="col-12 col-md-6 d-flex align-items-stretch">
                <div class="p-4 shadow-sm text-center wow fadeIn">
                    <p class="mb-0 title"><?php echo $datos["contenido"]["vision"]["TIT"]; ?></p>
                    <hr/>
                    <?php echo $datos["contenido"]["vision"]["TEX"]; ?>

                </div>
            </div>
            <div class="col-12 col-md-6 d-flex align-items-stretch">
                <div class="p-4 shadow-sm text-center wow bouceIn">
                    <p class="mb-0 title"><?php echo $datos["contenido"]["mision"]["TIT"]; ?></p>
                    <hr/>
                    <?php echo $datos["contenido"]["mision"]["TEX"]; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts_distribuidor'); ?>
<script>
    $(document).ready(function() {
        $(".input[data-year]:first-child").click();
    });
    change = function(t) {
        year = $(t).data("year");
        $(".input[data-year].active").removeClass("active");
        $(".text[data-year]").addClass("d-none");
        $(t).addClass("active");
        $(`.text[data-year="${year}"]`).removeClass("d-none");
    };
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\ventor\resources\views/page/parts/empresa.blade.php ENDPATH**/ ?>
<h3 class="title">{{$title}}</h3>

<section class="mt-3">
    <div class="container-fluid">
        @include('adm.parts.contenido.elemento.' . $seccion)
    </div>
</section>
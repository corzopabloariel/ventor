<div class="d-flex align-items-center justify-content-center" style="height: 100vh;">
    <h1>Bienvenido<br/>{{Auth::user()["name"]}}</h1>
</div>
<!DOCTYPE html>
<html>
<body>
    <p><strong>EMPRESA O NOMBRE:</strong> {{$empresa}}</p>
    <p><strong>E-MAIL:</strong> <a href="mailto:{{$email}}">{{$email}}</a></p>
    <p><strong>TELÉFONO:</strong> {{$telefono}}</p>
    <p><strong>LOCALIDAD:</strong> {{$localidad}}</p>
    <p><strong>MENSAJE:</strong> {{$mensaje}}</p>
</body>
</html>
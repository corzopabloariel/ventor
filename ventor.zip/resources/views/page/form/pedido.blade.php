<!DOCTYPE html>
<html>
<body>
    {{$mensaje}}
</body>
</html>
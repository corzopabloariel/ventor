<!DOCTYPE html>
<html>
<body>
    {{ $mensaje[0] }}<br/>
    {{ $mensaje[1] }}
</body>
</html>
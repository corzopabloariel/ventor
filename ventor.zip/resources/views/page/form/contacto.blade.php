<!DOCTYPE html>
<html>
<body>
    <p><strong>NOMBRE:</strong> {{$nombre}} {{$apellido}}</p>
    <p><strong>E-MAIL:</strong> <a href="mailto:{{$email}}">{{$email}}</a></p>
    <p><strong>TELÉFONO:</strong> {{$telefono}}</p>
    <p><strong>MENSAJE:</strong> {{$mensaje}}</p>
</body>
</html>
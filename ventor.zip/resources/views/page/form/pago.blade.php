<!DOCTYPE html>
<html>
<body>
    <p><strong>NRO DE CLIENTE:</strong> {{$nroCliente}}</p>
    <p><strong>RAZÓN:</strong> {{$razon}}</p>
    <p><strong>FECHA:</strong> {{$fecha}}</p>
    <p><strong>IMPORTE:</strong> {{$importe}}</p>
    <p><strong>BANCO:</strong> {{$banco}} - {{$sucursal}}</p>
    <p><strong>FACTURAS:</strong> {{$facturas}}</p>
    <p><strong>DESCUENTO:</strong> {{$descuento}}</p>
</body>
</html>
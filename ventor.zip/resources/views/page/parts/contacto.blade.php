<div class="wrapper-contacto py-5">
    <div class="container mb-5">
        <h3 class="title text-uppercase" style="font-size: 32px; color: #595959; font-weight: 200">Sede ciudad de buenos aires</h3>
        <div class="row numeros">
            @foreach($datos["numeros"] AS $n)
                @if($n["is_vendedor"] == 0)
                <div class="col-12 col-md-4 col-lg-3 d-flex align-items-stretch mt-2">
                    <article class="article w-100">
                        <p class="title text-uppercase">{{ $n["nombre"] }}</p>
                        <p class="title">{{ $n["persona"] }}</p>
                        
                        <p><strong>Interno</strong> {{ $n["interno"] }}</p>
                        @if(!empty($n["celular"]))
                            <p><strong>Celular</strong> {{ $n["celular"] }}</p>
                        @endif
                    </article>
                </div>
                @endif
            @endforeach
        </div>
    </div>
    <div class="container-fluid mb-2">
        <div class="row">
            <div class="col-12 col-md-6 pl-0">
                <div id="map" style="height: 450px;"></div>
            </div>
            <div class="col-12 col-md-6"></div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-4">
                <h3 class="title mb-3">Ventor</h3>
                <ul class="list-unstyled info mb-0">
                    <li class="d-flex align-items-start">
                        <i class="fas fa-map-marker-alt"></i>
                        <div class="ml-2">
                            <p class="mb-0">{!! $datos["empresa"]["domicilio"]["calle"] !!} {!! $datos["empresa"]["domicilio"]["altura"] !!}</p>
                            <p class="mb-0">Ciudad Autónoma de Buenos Aires</p>
                        </div>
                    </li>
                    <li class="d-flex align-items-start">
                        <i class="fas fa-phone-volume"></i>
                        <div class="ml-2">
                            @foreach($datos["empresa"]["telefono"]["tel"] as $t)
                                <a title="{{$t}}" class="text-truncate d-block" href="tel:{{$t}}">{!!$t!!}</a>
                            @endforeach
                        </div>
                    </li>
                    <li class="d-flex align-items-start">
                        <i class="far fa-envelope"></i>
                        <div class="ml-2">
                            @foreach($datos["empresa"]["email"] as $e)
                                <a title="{{$e}}" class="text-truncate d-block" href="mailto:{!!$e!!}" target="blank">{!!$e!!}</a>
                            @endforeach
                        </div>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-8">
                <form action="{{ url('/form/contacto') }}" novalidate id="form" onsubmit="event.preventDefault(); enviar(this);" method="post">
                    {{ csrf_field() }}
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <input placeholder="Nombre *" required type="text" value="{{ old('nombre') }}" name="nombre" class="form-control">
                        </div>
                        <div class="col-12 col-md-6">
                            <input placeholder="Apellido" type="text" value="{{ old('apellido') }}" name="apellido" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-12">
                            <input placeholder="Email *" required type="email" name="email" value="{{ old('email') }}" class="form-control">
                        </div>
                        <div class="col-lg-6 col-12">
                            <input placeholder="Teléfono" type="phone" name="telefono" value="{{ old('telefono') }}" class="form-control">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <textarea name="mensaje" required rows="5" placeholder="Mensaje *" class="form-control">{{ old('mensaje') }}</textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-12">
                            <div class="g-recaptcha" data-sitekey="6Lf8ypkUAAAAAKVtcM-8uln12mdOgGlaD16UcLXK"></div>
                        </div>
                        <div class="col-lg-6 col-12">
                        <div class="form-check">
                            <input class="form-check-input" required data-placeholder="Términos y condiciones" type="checkbox" value="1" name="terminos" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">
                                Acepto los términos y condiciones de privacidad
                            </label>
                        </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <button type="submit" class="btn px-5 text-white text-uppercase">enviar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@push('scripts')
<script src='https://www.google.com/recaptcha/api.js'></script>

<script>

function zfill(number, width) {
    var numberOutput = Math.abs(number); /* Valor absoluto del número */
    var length = number.toString().length; /* Largo del número */ 
    var zero = "0"; /* String de cero */  
    
    if (width <= length) {
        if (number < 0) {
             return ("-" + numberOutput.toString()); 
        } else {
             return numberOutput.toString(); 
        }
    } else {
        if (number < 0) {
            return ("-" + (zero.repeat(width - length)) + numberOutput.toString()); 
        } else {
            return ((zero.repeat(width - length)) + numberOutput.toString()); 
        }
    }
}
var map;
function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
        zoom: 4,
        center: {lat: -40, lng: -60}
    });
    var mapLayers = [];
    for (var i = 26; i >= 1; i--) {
        var mapLayer = new google.maps.Data();
        mapLayer.loadGeoJson(`{{ asset('js/googlemaps') }}/map${zfill(i, 2)}.geojson`);
        mapLayer.setStyle({
        fillColor: '#'+Math.floor(Math.random()*16777215).toString(16),
        strokeColor: '#000',
        strokeOpacity: 1,
        strokeWeight: 1
        });
        // Set mouseover event for each feature.
        mapLayer.addListener('mouseover', function(event) {
            //document.getElementById('info-box').textContent = event.feature.getProperty('description');
        });
        mapLayer.setMap(map);
    }
}

validar = function(t, marca = true, visible = true) {
    let flag = 1;
    $(t).find('*[required]').each(function() {
        if($(this).is(":visible")) {
            flagI = true;
            if($(this).attr("type") !== undefined) {
                if($(this).attr("type") == "file" || $(this).attr("type") == "date")
                    flagI = false;
            }
            if(flagI) {
                if($(this).is(":invalid") || $(this).val() == "") {
                    flag = 0;
                    if(marca) $(this).addClass("has-error");
                }
            }
        }
    });
    return flag;
};
validarSTRING = function(t) {
    let string = "";
    $(t).find('*[required]').each(function() {
        flag = true;
        if($(this).attr("type") !== undefined) {
            if($(this).attr("type") == "file" || $(this).attr("type") == "date")
                flag = false;
        }
        if(flag) {
            if($(this).is(":invalid") || $(this).val() == "") {
                if(string != "") string += ", ";
                if($(this).attr("placeholder") === undefined)
                    string += $(this).data("placeholder");
                else {
                    t = $(this).attr("placeholder");
                    if(t.indexOf("*") >= 0)
                        t = t.replace(" *","");
                    string += t;
                }
            }
        }
    });
    return string;
}
enviar = function(t) {
    if(!validar($("#form"))) {
        str = validarSTRING($("#form"));
        alertify.notify(`Complete ${str} para enviar`, 'warning');
        return false;
    }
    document.getElementById("form").submit();
}

</script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAZUlidy4Exa3bvZLRh4qgqx4lwlLy6khw&callback=initMap"></script>
@endpush
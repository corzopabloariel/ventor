<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FamiliaVentor extends Model
{
    protected $table = "familiasventor";
    protected $fillable = [
        'usr_stmati'
    ];
}
